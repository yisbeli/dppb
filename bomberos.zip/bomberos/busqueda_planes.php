<?php	include_once 'librerias/cabecera.php'; ?>
	<div class="container"><br>
<?php
	include_once 'librerias/nivel3_r.php';
?>
	</div>
<?php	include_once 'librerias/pie.php'; ?>
