<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Sistema para el laboratorio de simulación</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap-3.3.5/css/bootstrap.css">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-3.3.5/css/bootstrap-responsive.css">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>
<body>
	<header>
		<div class="container">
			<img src="img/sinfondo.png" class="img-responsive bg-danger" height="500px">
		</div>
	</header>