	<footer id="pie">
		<div class="container">
			<p class="bg-danger text-center">
				&copy; <?php echo date("Y"); ?> Direccion Estadal del Cuerpo de Bomberos del Estado Bolivariano Mérida - Venezuela<br />
				<b>Universidad Politécnica Territorial de Mérida "Kléber Ramírez"</b>
			</p>
		</div>
	</footer>
	<script src="css/bootstrap-3.3.5/js/jquery-1.11.3.js" ></script>
	<script src="css/bootstrap-3.3.5/js/bootstrap.js"></script>
</body>
</html>